import axios, { AxiosInstance } from 'axios'

/**
 * ============================================
 * API CLIENT - Microservices Gateway Integration
 * ============================================
 * 
 * Routes through Spring Cloud Gateway (Port 8862)
 * Services discovered via Eureka
 * 
 * GATEWAY: http://localhost:8862
 * EUREKA: http://localhost:8761
 * 
 * ROUTING PATTERN: /{EUREKA-SERVICE-NAME}/api/{endpoint}
 * 
 * MICROSERVICES (Registered with Eureka):
 * - USER-SERVICE: /users/api/...
 * - SALON-SERVICE: /salons/api/...
 * - SERVICE-OFFERING: /services/api/...
 * - CATEGORY-SERVICE: /categories/api/...
 * - BOOKING-SERVICE: /bookings/api/...
 * - PAYMENT-SERVICE: /payments/api/...
 * - NOTIFICATION-SERVICE: /notifications/api/...
 */

const getGatewayUrl = () => {
  if (typeof import.meta !== 'undefined' && import.meta.env?.VITE_GATEWAY_URL) {
    return import.meta.env.VITE_GATEWAY_URL
  }
  if (typeof window !== 'undefined' && (window as any).__ENV__?.REACT_APP_GATEWAY_URL) {
    return (window as any).__ENV__.REACT_APP_GATEWAY_URL
  }
  return 'http://localhost:8862'
}

const GATEWAY_URL = getGatewayUrl()

class APIClient {
  private client: AxiosInstance

  constructor() {
    this.client = axios.create({
      baseURL: GATEWAY_URL,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json',
      },
      withCredentials: false,
    })

    // REQUEST INTERCEPTOR: Attach JWT token to all requests
    this.client.interceptors.request.use(
      (config) => {
        const token = localStorage.getItem('authToken') || localStorage.getItem('token')
        if (token) {
          config.headers.Authorization = `Bearer ${token}`
        }
        return config
      },
      (error) => Promise.reject(error)
    )

    // RESPONSE INTERCEPTOR: Handle errors and token refresh
    this.client.interceptors.response.use(
      (response) => response,
      (error) => {
        if (error.response?.status === 401) {
          localStorage.removeItem('authToken')
          localStorage.removeItem('token')
          localStorage.removeItem('user')
          window.location.href = '/login'
        }
        return Promise.reject(error)
      }
    )
  }

  // ✅ Helper: Convert MongoDB ObjectId to string
  private convertObjectIdToString(obj: any): string {
    if (!obj) return ''
    
    // If it's already a string, return it
    if (typeof obj === 'string') return obj
    
    // ✅ NEW: Handle {timestamp, date} format from backend
    if (obj.timestamp) {
      // Create a unique ID from timestamp
      return obj.timestamp.toString()
    }
    
    // If it's an object with $oid property (MongoDB ObjectId format)
    if (obj.$oid) return obj.$oid
    
    // If it has a toString method
    if (obj.toString && typeof obj.toString === 'function') {
      const str = obj.toString()
      // Don't return "[object Object]"
      if (str !== '[object Object]') return str
    }
    
    // Last resort: try to get any id-like property
    return obj.id || obj._id || ''
  }

  // ✅ Helper: Transform salon data
  private transformSalon(salon: any) {
    if (!salon) return null
    
    // ✅ Backend returns 'id' field (not _id), and it's an object
    const salonId = this.convertObjectIdToString(salon.id)
    
    return {
      ...salon,
      id: salonId,
      _id: salonId,  // Keep both for compatibility
      images: Array.isArray(salon.images) ? salon.images : [],
      rating: typeof salon.rating === 'number' ? salon.rating : 0,
      city: salon.city || '',
    }
  }

  // ✅ Helper: Transform array of salons
  private transformSalons(data: any) {
    const salons = Array.isArray(data) ? data : []
    return salons.map(salon => this.transformSalon(salon)).filter(Boolean)
  }

  // ==================== USER SERVICE (Eureka: USER-SERVICE) ====================
  
  async registerUser(data: {
    name: string
    email: string
    password: string
    role: 'CUSTOMER' | 'SALON_OWNER' | 'ADMIN'
    phone: string
  }) {
    const response = await this.client.post('/users/api/users/register', data)
    if (response.data.accessToken) {
      localStorage.setItem('authToken', response.data.accessToken)
      localStorage.setItem('token', response.data.accessToken)
      localStorage.setItem('user', JSON.stringify(response.data.user))
    }
    return response.data
  }

  async loginUser(email: string, password: string) {
    const response = await this.client.post('/users/api/users/login', { email, password })
    if (response.data.accessToken) {
      localStorage.setItem('authToken', response.data.accessToken)
      localStorage.setItem('token', response.data.accessToken)
      localStorage.setItem('user', JSON.stringify(response.data.user))
    }
    return response.data
  }

  async login(data: { email: string; password: string }) {
    const response = await this.client.post('/users/api/users/login', data)
    if (response.data.accessToken) {
      localStorage.setItem('authToken', response.data.accessToken)
      localStorage.setItem('token', response.data.accessToken)
      localStorage.setItem('user', JSON.stringify(response.data.user))
    }
    return response.data
  }

  async logoutUser() {
    localStorage.removeItem('authToken')
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    return { message: 'Logged out successfully' }
  }

  async getUserProfile(userId: string) {
    return (await this.client.get(`/users/api/users/${userId}`)).data
  }

  async updateUserProfile(userId: string, data: any) {
    const response = await this.client.put(`/users/api/users/${userId}`, data)
    localStorage.setItem('user', JSON.stringify(response.data))
    return response.data
  }

  // ==================== SALON SERVICE (Eureka: SALON-SERVICE) ====================

  async getSalons(page = 1, limit = 10, search?: string) {
    const params = new URLSearchParams({
    page: page.toString(),
    limit: limit.toString(),
    ...(search && { search }),
  })
  
  const response = await this.client.get(`/salons/api/salons?${params}`)
  
  const transformed = this.transformSalons(response.data)
  
  
  return transformed
  }

  async getSalonById(id: string) {
    const response = await this.client.get(`/salons/api/salons/${id}`)
    return this.transformSalon(response.data)
  }

  async searchSalons(query: string, city?: string) {
    const params = new URLSearchParams({
      search: query,
      ...(city && { city }),
    })
    
    const response = await this.client.get(`/salons/api/salons/search?${params}`)
    return this.transformSalons(response.data)
  }

  async createSalon(data: any) {
    const response = await this.client.post('/salons/api/salons', data)
    return this.transformSalon(response.data)
  }

  async updateSalon(id: string, data: any) {
    const response = await this.client.put(`/salons/api/salons/${id}`, data)
    return this.transformSalon(response.data)
  }

  async deleteSalon(id: string) {
    return (await this.client.delete(`/salons/api/salons/${id}`)).data
  }

  // ==================== SERVICE OFFERING (Eureka: SERVICE-OFFERING) ====================

  async getServicesBySalonId(salonId: string, page = 1, limit = 20) {
    const params = new URLSearchParams({
      page: page.toString(),
      limit: limit.toString(),
    })
    return (await this.client.get(`/services/api/salons/${salonId}/services?${params}`)).data
  }

  async getServiceById(id: string) {
    return (await this.client.get(`/services/api/services/${id}`)).data
  }

  async getServicesByCategory(categoryId: string) {
    return (await this.client.get(`/services/api/services/category/${categoryId}`)).data
  }

  async createService(data: any) {
    return (await this.client.post('/services/api/services', data)).data
  }

  async updateService(id: string, data: any) {
    return (await this.client.put(`/services/api/services/${id}`, data)).data
  }

  async deleteService(id: string) {
    return (await this.client.delete(`/services/api/services/${id}`)).data
  }

  // ==================== CATEGORY SERVICE (Eureka: CATEGORY-SERVICE) ====================

  async getCategories() {
    return (await this.client.get('/categories/api/categories')).data
  }

  async getCategoryById(id: string) {
    return (await this.client.get(`/categories/api/categories/${id}`)).data
  }

  async createCategory(data: any) {
    return (await this.client.post('/categories/api/categories', data)).data
  }

  async updateCategory(id: string, data: any) {
    return (await this.client.put(`/categories/api/categories/${id}`, data)).data
  }

  async deleteCategory(id: string) {
    return (await this.client.delete(`/categories/api/categories/${id}`)).data
  }

  // ==================== BOOKING SERVICE (Eureka: BOOKING-SERVICE) ====================

  async createBooking(data: {
    userId: string
    salonId: string
    serviceId: string
    bookingDate: string
    bookingTime: string
    notes?: string
  }) {
    return (await this.client.post('/bookings/api/bookings', data)).data
  }

  async getBookingById(id: string) {
    return (await this.client.get(`/bookings/api/bookings/${id}`)).data
  }

  async getUserBookings(userId: string, page = 1, limit = 10) {
    const params = new URLSearchParams({
      page: page.toString(),
      limit: limit.toString(),
    })
    return (await this.client.get(`/bookings/api/users/${userId}/bookings?${params}`)).data
  }

  async getSalonBookings(salonId: string, page = 1, limit = 10) {
    const params = new URLSearchParams({
      page: page.toString(),
      limit: limit.toString(),
    })
    return (await this.client.get(`/bookings/api/salons/${salonId}/bookings?${params}`)).data
  }

  async updateBooking(id: string, data: any) {
    return (await this.client.put(`/bookings/api/bookings/${id}`, data)).data
  }

  async cancelBooking(id: string) {
    return (await this.client.post(`/bookings/api/bookings/${id}/cancel`, {})).data
  }

  async getAvailability(salonId: string, date: string) {
    return (await this.client.get(`/bookings/api/salons/${salonId}/availability?date=${date}`)).data
  }

  // ==================== PAYMENT SERVICE (Eureka: PAYMENT-SERVICE) ====================

  async createPayment(data: {
    bookingId: string
    amount: number
    paymentMethod: string
  }) {
    return (await this.client.post('/payments/api/payments', data)).data
  }

  async getPaymentById(id: string) {
    return (await this.client.get(`/payments/api/payments/${id}`)).data
  }

  async processPayment(
    id: string,
    details: {
      cardNumber?: string
      expiryDate?: string
      cvv?: string
      upiId?: string
    }
  ) {
    return (await this.client.post(`/payments/api/payments/${id}/process`, details)).data
  }

  async confirmPayment(id: string) {
    return (await this.client.post(`/payments/api/payments/${id}/confirm`, {})).data
  }

  async getPaymentHistory(userId: string, page = 1, limit = 10) {
    const params = new URLSearchParams({
      page: page.toString(),
      limit: limit.toString(),
    })
    return (await this.client.get(`/payments/api/users/${userId}/payments?${params}`)).data
  }

  async refundPayment(id: string, reason: string) {
    return (await this.client.post(`/payments/api/payments/${id}/refund`, { reason })).data
  }

  // ==================== NOTIFICATION SERVICE (Eureka: NOTIFICATION-SERVICE) ====================

  async getNotifications(userId: string, page = 1, limit = 20) {
    const params = new URLSearchParams({
      page: page.toString(),
      limit: limit.toString(),
    })
    return (await this.client.get(`/notifications/api/users/${userId}/notifications?${params}`)).data
  }

  async markNotificationAsRead(id: string) {
    return (await this.client.put(`/notifications/api/notifications/${id}/read`, {})).data
  }

  async sendEmailNotification(email: string, subject: string, message: string) {
    return (await this.client.post('/notifications/api/notifications/email', { email, subject, message })).data
  }
}

export const apiClient = new APIClient()
export default apiClient